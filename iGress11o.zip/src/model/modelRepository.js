let repo = require('./User');
repo = require('./Adress');
repo = require('./Combo');
repo = require('./Gender');
repo = require('./Image');
repo = require('./Ingress');
repo = require('./Item');
repo = require('./Member');

repo = require('./MovieTheater');
repo = require('./News');
repo = require('./Order');
repo = require('./PaymentMethod');
repo = require('./Product');
repo = require('./Review');
repo = require('./Room');
repo = require('./Schedule');
repo = require('./Movie');
repo = require('./Seat');
repo = require('./Team');
repo = require('./MovieSync');
repo = require('./MovieXGenders');


module.exports = repo;