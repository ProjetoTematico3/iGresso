# iGresso

<p align="center">
  <a href="#-projeto">Projeto</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
  <a href="#-tecnologias">Tecnologias</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
  <a href="#-como-iniciar-o-projeto">Como Iniciar o projeto</a>
</p>


# 💻 Projeto 

> Aplicativo de compra de ingresso e review de filmes


# 🚀 Tecnologias

Esse projeto foi feito com as seguinte tecnologias:

- Javascript.
- NodeJS.

# 🏃 Como iniciar o projeto?

1. Abrir terminal do vscode

- npm install   

2. Para executar a aplicação

-  node src/index.js